// MYSQL에 있는 맛집 데이터 모두 가져오기


var data = [
    {
        title: "서울",
        content: "서울 남산",
        date: "2021-02-12",
        lat: 37.551150,
        lng: 126.991464,
    },
    {
        title: "서울",
        content: "서울 용산",
        date: "2021-02-12",
        lat: 37.531040,
        lng: 126.978978,
    }
]